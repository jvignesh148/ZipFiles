# Postman Exercise 3 — REST API Testing with Postman

## 1. Objective

Create a Postman collection covering the following REST concepts:
- **GET Request** in Postman
- **Response** in Postman
- **Request Parameters** in Postman
- **POST Request** using Postman
- Also covered: **PUT** and **DELETE** as required by the exercise.

## 2. APIs Used

| API                     | Base URL                                | Notes                                    |
|-------------------------|------------------------------------------|------------------------------------------|
| Star Wars API (SWAPI)   | `https://swapi.dev/api/`                | Substituted for `swapi.co` (deprecated)  |
| JSONPlaceholder         | `https://jsonplaceholder.typicode.com`  | Substituted for `api.vschool.io` (offline) |

> **Note:** The original URLs in the exercise (`swapi.co` and
> `api.vschool.io`) are no longer reachable. The two substitutes above
> are well-known, free, public REST testing APIs that match the exercise
> requirements: SWAPI for read-only GET demos and JSONPlaceholder for
> CRUD (GET/POST/PUT/DELETE) operations against a "todos"-style endpoint.

## 3. How to Use the Submitted Postman Collection

1. Open Postman.
2. Click **Import** (top-left).
3. Choose **File** → browse to
   `PostmanCollection/SoapUI_Exercise3_Postman.postman_collection.json`.
4. Click **Import**.
5. The collection `SoapUI_Exercise3_Postman` appears in the left sidebar
   with two folders containing all 11 requests.

## 4. Part 1 — Star Wars API

### 4.1 GET a List of Planets
- **Method:** GET
- **URL:**    `https://swapi.dev/api/planets/`
- **Response:** 200 OK, paginated list of planets with name, climate,
  terrain, population, etc.
- Files: `RequestResponse/01_GetAllPlanets_Request.txt`,
         `RequestResponse/02_GetAllPlanets_Response.json`

### 4.2 GET a Single Person
- **Method:** GET
- **URL:**    `https://swapi.dev/api/people/1/`
- **Response:** 200 OK, person with name = "Luke Skywalker", height,
  hair color, films, vehicles, starships, etc.
- Files: `RequestResponse/03_GetPersonById_Request.txt`,
         `RequestResponse/04_GetPersonById_Response.json`

### 4.3 Request Parameters Demo
- **Method:** GET
- **URL:**    `https://swapi.dev/api/people/?search=Luke`
- **Params tab:** key=`search`, value=`Luke`
- **Response:** 200 OK with filtered results matching the search term.
- Demonstrates how Postman builds query parameters from the Params tab.

## 5. Part 2 — Todo API CRUD Operations

### 5.1 GET One ID Property
- **Method:** GET
- **URL:**    `https://jsonplaceholder.typicode.com/todos/1`
- **Response:** 200 OK, single todo with userId, id, title, completed.
- Files: `RequestResponse/05_GetTodoById_Request.txt`,
         `RequestResponse/06_GetTodoById_Response.json`

### 5.2 DELETE One ID Property
- **Method:** DELETE
- **URL:**    `https://jsonplaceholder.typicode.com/todos/1`
- **Response:** 200 OK with empty body `{}`.
- Files: `RequestResponse/07_DeleteTodo_Request.txt`,
         `RequestResponse/08_DeleteTodo_Response.json`

### 5.3 PUT One ID Property
- **Method:** PUT
- **URL:**    `https://jsonplaceholder.typicode.com/todos/1`
- **Body (raw JSON):**
  ```json
  {
    "userId": 1,
    "id": 1,
    "title": "Updated title from Postman",
    "completed": true
  }
  ```
- **Response:** 200 OK with the updated object echoed back.
- Files: `RequestResponse/09_PutTodo_Request.txt`,
         `RequestResponse/10_PutTodo_Response.json`

### 5.4 POST 3 New Objects
Each POST uses the template specified in the exercise.

**POST #1 — "Buy groceries"** (files: `11_*`, `12_*`)
```json
{
  "title": "Buy groceries",
  "description": "Weekly shopping",
  "price": 50,
  "imgUrl": "http://example.com/groceries.jpg",
  "completed": false
}
```

**POST #2 — "Read a book"** (files: `13_*`, `14_*`)
```json
{
  "title": "Read a book",
  "description": "Finish the new sci-fi novel",
  "price": 15,
  "imgUrl": "http://example.com/book.jpg",
  "completed": true
}
```

**POST #3 — "Go for a run"** (files: `15_*`, `16_*`)
```json
{
  "title": "Go for a run",
  "description": "5km morning run",
  "price": 0,
  "imgUrl": "http://example.com/run.jpg",
  "completed": false
}
```

Each POST returns `201 Created` with the object echoed back and an
`id` field added by the server.

### 5.5 Final GET to Confirm
- **Method:** GET
- **URL:**    `https://jsonplaceholder.typicode.com/posts`
- Returns all 100 existing posts.

> Important caveat: JSONPlaceholder does NOT actually persist POSTed
> data — it's a "fake" API for testing. The POST responses confirm the
> server accepted the request (201 Created with `id: 101`), but the
> final GET will not show your new items. This is documented behavior
> and acceptable for this exercise. With a real persistent API, the GET
> would return all originals plus your three new objects.

## 6. Postman Concepts Demonstrated

| Concept                    | Where Shown                                          |
|----------------------------|------------------------------------------------------|
| GET Request                | All 4 GET requests (planets, person, search, todo)   |
| Response viewing           | Body tab, Status code, Time, Size in every request   |
| Request Parameters         | "GET People with Query Parameter" (Params tab)       |
| POST Request               | 3 POST requests with raw JSON body                   |
| PUT Request                | Update todo by ID                                    |
| DELETE Request             | Delete todo by ID                                    |
| Headers                    | Content-Type: application/json on POST/PUT           |
| Body (raw JSON mode)       | All POST and PUT requests                            |

## 7. Folder Structure

```
Postman_Exercise3/
├── README.md
├── PostmanCollection/
│   └── SoapUI_Exercise3_Postman.postman_collection.json
├── RequestResponse/
│   ├── 01_GetAllPlanets_Request.txt
│   ├── 02_GetAllPlanets_Response.json
│   ├── 03_GetPersonById_Request.txt
│   ├── 04_GetPersonById_Response.json
│   ├── 05_GetTodoById_Request.txt
│   ├── 06_GetTodoById_Response.json
│   ├── 07_DeleteTodo_Request.txt
│   ├── 08_DeleteTodo_Response.json
│   ├── 09_PutTodo_Request.txt
│   ├── 10_PutTodo_Response.json
│   ├── 11_PostObject1_Request.txt
│   ├── 12_PostObject1_Response.json
│   ├── 13_PostObject2_Request.txt
│   ├── 14_PostObject2_Response.json
│   ├── 15_PostObject3_Request.txt
│   └── 16_PostObject3_Response.json
└── Screenshots/                                  (optional - add if required)
```

## 8. How to Reproduce the Exercise From Scratch

1. Install Postman (`https://www.postman.com/downloads/`) and launch.
2. Create a new collection named `SoapUI_Exercise3_Postman`.
3. For each request listed above:
   - Click **+** (new tab) → set Method and URL → click **Send** → see response.
   - Save into the collection (`Ctrl+S` or "Save" button).
4. For POST and PUT: in the **Body** tab pick **raw** → select **JSON** in
   dropdown → paste the body.
5. For query parameters: use the **Params** tab below the URL.
6. Export the collection: right-click collection → **Export** →
   Collection v2.1 → save as `.postman_collection.json`.

## 9. Conclusion

This exercise demonstrates the complete REST request lifecycle in
Postman: building requests with different HTTP verbs, attaching JSON
bodies, using query parameters, inspecting JSON responses, and
organizing everything into an exportable, shareable collection.
